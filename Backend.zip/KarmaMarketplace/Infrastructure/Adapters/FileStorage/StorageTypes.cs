﻿namespace KarmaMarketplace.Infrastructure.Adapters.FileStorage
{
    public enum StorageTypes
    {
        Local, 
        S3, 
        Minio
    }
}
