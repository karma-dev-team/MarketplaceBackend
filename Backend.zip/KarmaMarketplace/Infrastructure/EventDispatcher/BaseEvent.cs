﻿namespace KarmaMarketplace.Infrastructure.EventDispatcher
{
    public abstract class BaseEvent
    {
    }
}
