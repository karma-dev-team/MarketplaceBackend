﻿namespace KarmaMarketplace.Domain.Staff.Enums
{
    public enum TicketStatus
    {
        Open,
        Closed,
        InProgress
    }
}
