﻿using KarmaMarketplace.Infrastructure.EventDispatcher;

namespace KarmaMarketplace.Domain.Common
{
    public abstract class DomainEvent : BaseEvent
    {
    }
}
