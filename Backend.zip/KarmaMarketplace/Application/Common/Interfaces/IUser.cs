﻿namespace KarmaMarketplace.Application.Common.Interfaces
{
    public interface IUser
    {
        Guid? Id { get; }
    }
}
