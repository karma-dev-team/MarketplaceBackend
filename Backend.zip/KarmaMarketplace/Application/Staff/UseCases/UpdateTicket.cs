﻿namespace KarmaMarketplace.Application.Staff.UseCases
{
    public class UpdateTicket
    {
    }
}
