﻿using KarmaMarketplace.Application.Staff.Interfaces;

namespace KarmaMarketplace.Application.Staff
{
    public class StaffService : IStaffService
    {
    }
}
