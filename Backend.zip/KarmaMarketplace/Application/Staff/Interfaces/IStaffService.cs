﻿namespace KarmaMarketplace.Application.Staff.Interfaces
{
    public class IStaffService
    {
    }
}
