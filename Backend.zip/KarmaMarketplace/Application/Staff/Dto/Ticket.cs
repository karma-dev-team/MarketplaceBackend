﻿namespace KarmaMarketplace.Application.Staff.Dto
{
    public class Ticket
    {
    }
}
