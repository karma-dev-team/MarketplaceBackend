﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KarmaMarketplace.Presentation.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProviderControllers : ControllerBase
    {
    }
}
